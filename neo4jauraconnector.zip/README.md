# lambda-neo4j
Creates the Lambda function to push data to Neo4j Aura
